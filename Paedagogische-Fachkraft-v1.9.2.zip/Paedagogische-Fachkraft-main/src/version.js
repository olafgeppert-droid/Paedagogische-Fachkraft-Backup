// src/version.js
export const appVersion = "1.9.2";
